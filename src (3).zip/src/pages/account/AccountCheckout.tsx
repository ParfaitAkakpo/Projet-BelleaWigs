// src/pages/account/AccountShop.tsx
import Shop from "@/pages/Shop";
export default function AccountShop() {
  return <Shop />;
}
