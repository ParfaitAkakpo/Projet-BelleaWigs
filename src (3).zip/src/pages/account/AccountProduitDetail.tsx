// src/pages/account/AccountProductDetail.tsx
import ProductDetail from "@/pages/ProductDetail";
export default function AccountProductDetail() {
  return <ProductDetail />;
}
