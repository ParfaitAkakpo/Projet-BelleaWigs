// src/pages/account/AccountCart.tsx
import Cart from "@/pages/Cart";
export default function AccountCart() {
  return <Cart />;
}
