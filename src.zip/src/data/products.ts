export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  category: 'natural-wigs' | 'synthetic-wigs' | 'extensions';
  images: string[];
  inStock: boolean;
  stockCount: number;
  featured: boolean;
  rating: number;
  reviewCount: number;
  details: string[];
}

export const products: Product[] = [
  {
    id: "1",
    name: "Perruque Naturelle Ondulée",
    description: "Perruque en cheveux humains 100% naturels, ondulation légère et naturelle. Parfaite pour un look élégant au quotidien.",
    price: 85000,
    originalPrice: 95000,
    category: "natural-wigs",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 12,
    featured: true,
    rating: 4.8,
    reviewCount: 45,
    details: ["Cheveux 100% humains", "Longueur: 45cm", "Densité: 150%", "Dentelle frontale HD"]
  },
  {
    id: "2",
    name: "Perruque Lisse Brésilienne",
    description: "Cheveux brésiliens de qualité supérieure, lisses et soyeux. Peut être colorée et stylisée.",
    price: 120000,
    category: "natural-wigs",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 8,
    featured: true,
    rating: 4.9,
    reviewCount: 67,
    details: ["Cheveux brésiliens vierges", "Longueur: 55cm", "Densité: 180%", "Fermeture 4x4"]
  },
  {
    id: "3",
    name: "Perruque Bouclée Afro",
    description: "Belle perruque aux boucles naturelles africaines. Volume et élégance garantis.",
    price: 75000,
    originalPrice: 85000,
    category: "natural-wigs",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 15,
    featured: false,
    rating: 4.7,
    reviewCount: 32,
    details: ["Cheveux humains texturés", "Longueur: 35cm", "Densité: 150%", "Sans colle"]
  },
  {
    id: "4",
    name: "Perruque Synthétique Longue",
    description: "Perruque synthétique de haute qualité, résistante à la chaleur. Style longue et lisse.",
    price: 25000,
    category: "synthetic-wigs",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 25,
    featured: true,
    rating: 4.5,
    reviewCount: 89,
    details: ["Fibre résistante à la chaleur", "Longueur: 60cm", "Légère et confortable", "Prête à porter"]
  },
  {
    id: "5",
    name: "Perruque Bob Synthétique",
    description: "Style bob moderne et chic. Parfaite pour les femmes actives qui veulent un look professionnel.",
    price: 18000,
    originalPrice: 22000,
    category: "synthetic-wigs",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 30,
    featured: false,
    rating: 4.6,
    reviewCount: 54,
    details: ["Fibre premium", "Longueur: 25cm", "Style pré-coupé", "Facile à entretenir"]
  },
  {
    id: "6",
    name: "Perruque Colorée Fantaisie",
    description: "Perruque synthétique aux couleurs vibrantes. Idéale pour les occasions spéciales.",
    price: 20000,
    category: "synthetic-wigs",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 18,
    featured: false,
    rating: 4.4,
    reviewCount: 28,
    details: ["Fibre colorée premium", "Longueur: 45cm", "Couleurs disponibles: rose, violet, bleu", "Résistante"]
  },
  {
    id: "7",
    name: "Extensions Clip-in Naturelles",
    description: "Extensions à clips en cheveux 100% humains. Volume instantané et naturel.",
    price: 45000,
    category: "extensions",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 20,
    featured: true,
    rating: 4.8,
    reviewCount: 76,
    details: ["7 pièces par set", "Longueur: 50cm", "Poids: 120g", "Cheveux remy"]
  },
  {
    id: "8",
    name: "Extensions à Tresser",
    description: "Mèches de qualité pour tressage. Douces, légères et durables.",
    price: 8000,
    category: "extensions",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 100,
    featured: false,
    rating: 4.6,
    reviewCount: 120,
    details: ["Fibre Kanekalon", "82 pouces", "Résistante à la chaleur", "Multiple couleurs"]
  },
  {
    id: "9",
    name: "Extensions Tape-in Premium",
    description: "Extensions adhésives invisibles. Application facile et résultat professionnel.",
    price: 55000,
    originalPrice: 65000,
    category: "extensions",
    images: ["/placeholder.svg"],
    inStock: true,
    stockCount: 10,
    featured: true,
    rating: 4.9,
    reviewCount: 41,
    details: ["20 pièces par pack", "Cheveux vierges", "Longueur: 45cm", "Réutilisables"]
  }
];

export const categories = [
  {
    id: "natural-wigs",
    name: "Perruques Naturelles",
    description: "Cheveux 100% humains pour un look naturel",
    image: "/placeholder.svg"
  },
  {
    id: "synthetic-wigs",
    name: "Perruques Synthétiques",
    description: "Style et qualité à prix accessible",
    image: "/placeholder.svg"
  },
  {
    id: "extensions",
    name: "Extensions",
    description: "Volume et longueur instantanés",
    image: "/placeholder.svg"
  }
];

export const testimonials = [
  {
    id: "1",
    name: "Adjoa K.",
    location: "Lomé",
    rating: 5,
    comment: "Qualité exceptionnelle! Ma perruque naturelle est parfaite. Livraison rapide et service client au top.",
    avatar: "/placeholder.svg"
  },
  {
    id: "2",
    name: "Ama D.",
    location: "Kpalimé",
    rating: 5,
    comment: "Je suis cliente depuis 2 ans. Les extensions sont toujours de qualité supérieure. Je recommande!",
    avatar: "/placeholder.svg"
  },
  {
    id: "3",
    name: "Félicia M.",
    location: "Sokodé",
    rating: 5,
    comment: "Prix raisonnables pour une qualité premium. Le service après-vente est excellent.",
    avatar: "/placeholder.svg"
  }
];

export const regions = [
  "Maritime",
  "Plateaux",
  "Centrale",
  "Kara",
  "Savanes"
];

export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('fr-FR').format(price) + ' FCFA';
};
