import { useState } from 'react';
import { Link } from 'react-router-dom';
import { User, Package, Heart, LogOut, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

const Account = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  // Mock login handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggedIn(true);
  };

  if (isLoggedIn) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-8">
          <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-8">
            Mon Compte
          </h1>

          <div className="grid md:grid-cols-4 gap-8">
            {/* Sidebar */}
            <aside className="space-y-2">
              {[
                { icon: User, label: 'Profil', active: true },
                { icon: Package, label: 'Mes Commandes', active: false },
                { icon: Heart, label: 'Favoris', active: false },
              ].map((item) => (
                <button
                  key={item.label}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-colors",
                    item.active
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:bg-muted"
                  )}
                >
                  <item.icon className="h-5 w-5" />
                  {item.label}
                </button>
              ))}
              <button
                onClick={() => setIsLoggedIn(false)}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-destructive hover:bg-destructive/10 transition-colors"
              >
                <LogOut className="h-5 w-5" />
                Déconnexion
              </button>
            </aside>

            {/* Content */}
            <div className="md:col-span-3">
              <div className="p-6 bg-card rounded-xl shadow-card">
                <h2 className="font-serif text-xl font-semibold text-foreground mb-6">
                  Informations du profil
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Nom complet</Label>
                    <Input defaultValue="Marie Akouavi" />
                  </div>
                  <div className="space-y-2">
                    <Label>Email</Label>
                    <Input defaultValue="marie@example.com" type="email" />
                  </div>
                  <div className="space-y-2">
                    <Label>Téléphone</Label>
                    <Input defaultValue="+228 90 00 00 00" type="tel" />
                  </div>
                  <div className="space-y-2">
                    <Label>Région</Label>
                    <Input defaultValue="Maritime" />
                  </div>
                </div>
                <Button className="mt-6">Sauvegarder</Button>
              </div>

              <div className="mt-6 p-6 bg-card rounded-xl shadow-card">
                <h2 className="font-serif text-xl font-semibold text-foreground mb-6">
                  Commandes récentes
                </h2>
                <div className="text-center py-8 text-muted-foreground">
                  <Package className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Aucune commande pour le moment</p>
                  <Link to="/shop">
                    <Button variant="outline" className="mt-4">
                      Découvrir nos produits
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center py-16">
      <div className="w-full max-w-md mx-4">
        <div className="text-center mb-8">
          <Link to="/" className="inline-block mb-6">
            <span className="font-serif text-3xl font-bold text-foreground">
              Bella<span className="text-primary">Wigs</span>
            </span>
          </Link>
          <h1 className="font-serif text-2xl font-bold text-foreground">
            {isLogin ? 'Connexion' : 'Créer un compte'}
          </h1>
          <p className="text-muted-foreground mt-2">
            {isLogin
              ? 'Connectez-vous pour accéder à votre compte'
              : 'Rejoignez-nous pour une expérience shopping personnalisée'}
          </p>
        </div>

        <div className="p-6 bg-card rounded-xl shadow-card">
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="name">Nom complet</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="name"
                    placeholder="Votre nom"
                    className="pl-10"
                    required
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="votre@email.com"
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Mot de passe</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  className="pl-10 pr-10"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {isLogin && (
              <div className="flex justify-end">
                <button type="button" className="text-sm text-primary hover:underline">
                  Mot de passe oublié?
                </button>
              </div>
            )}

            <Button type="submit" variant="hero" size="lg" className="w-full">
              {isLogin ? 'Se connecter' : 'Créer mon compte'}
            </Button>
          </form>

          <div className="mt-6 text-center text-sm">
            <span className="text-muted-foreground">
              {isLogin ? "Pas encore de compte?" : "Déjà un compte?"}
            </span>{' '}
            <button
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-primary font-medium hover:underline"
            >
              {isLogin ? "S'inscrire" : "Se connecter"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;
