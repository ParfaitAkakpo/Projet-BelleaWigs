import { Link } from 'react-router-dom';
import { ArrowRight, Truck, Shield, Award, Headphones } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProductCard from '@/components/ProductCard';
import { products, categories, testimonials, formatPrice } from '@/data/products';
import heroImage from '@/assets/hero-model.jpg';
import categoryNatural from '@/assets/category-natural.jpg';
import categorySynthetic from '@/assets/category-synthetic.jpg';
import categoryExtensions from '@/assets/category-extensions.jpg';

const categoryImages: Record<string, string> = {
  'natural-wigs': categoryNatural,
  'synthetic-wigs': categorySynthetic,
  'extensions': categoryExtensions,
};

const Index = () => {
  const featuredProducts = products.filter(p => p.featured);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-hero-gradient">
        <div className="container py-12 md:py-20 lg:py-28">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            <div className="space-y-6 animate-slide-up">
              <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium">
                ✨ Nouvelle Collection Disponible
              </span>
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                Révélez Votre <span className="text-gradient">Beauté Naturelle</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-lg">
                Découvrez notre collection exclusive de perruques et extensions de qualité premium. 
                Livraison rapide partout au Togo.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/shop">
                  <Button variant="hero" size="lg" className="w-full sm:w-auto">
                    Découvrir la Boutique
                    <ArrowRight className="h-5 w-5" />
                  </Button>
                </Link>
                <Link to="/shop?category=natural-wigs">
                  <Button variant="outline-primary" size="lg" className="w-full sm:w-auto">
                    Perruques Naturelles
                  </Button>
                </Link>
              </div>
              <div className="flex items-center gap-6 pt-4">
                <div className="text-center">
                  <p className="font-serif text-2xl font-bold text-foreground">500+</p>
                  <p className="text-xs text-muted-foreground">Clientes Satisfaites</p>
                </div>
                <div className="w-px h-10 bg-border"></div>
                <div className="text-center">
                  <p className="font-serif text-2xl font-bold text-foreground">100%</p>
                  <p className="text-xs text-muted-foreground">Qualité Premium</p>
                </div>
                <div className="w-px h-10 bg-border"></div>
                <div className="text-center">
                  <p className="font-serif text-2xl font-bold text-foreground">24h</p>
                  <p className="text-xs text-muted-foreground">Livraison Lomé</p>
                </div>
              </div>
            </div>
            <div className="relative animate-fade-in">
              <div className="relative rounded-2xl overflow-hidden shadow-glow">
                <img
                  src={heroImage}
                  alt="Belle femme avec perruque naturelle"
                  className="w-full h-auto object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-card p-4 rounded-xl shadow-card hidden md:block">
                <p className="font-serif text-lg font-semibold text-foreground">Perruques à partir de</p>
                <p className="text-2xl font-bold text-primary">{formatPrice(18000)}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">
              Nos Catégories
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Explorez notre sélection de perruques et extensions pour tous les styles et budgets
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6 lg:gap-8">
            {categories.map((category, idx) => (
              <Link
                key={category.id}
                to={`/shop?category=${category.id}`}
                className="group relative overflow-hidden rounded-2xl aspect-[3/4] animate-slide-up"
                style={{ animationDelay: `${idx * 100}ms` }}
              >
                <img
                  src={categoryImages[category.id]}
                  alt={category.name}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent"></div>
                <div className="absolute bottom-0 left-0 right-0 p-6 text-background">
                  <h3 className="font-serif text-xl font-bold mb-1">{category.name}</h3>
                  <p className="text-sm text-background/80 mb-3">{category.description}</p>
                  <span className="inline-flex items-center text-sm font-medium text-primary group-hover:gap-2 transition-all">
                    Voir la collection <ArrowRight className="h-4 w-4" />
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-12">
            <div>
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-2">
                Produits Populaires
              </h2>
              <p className="text-muted-foreground">
                Les favoris de nos clientes
              </p>
            </div>
            <Link to="/shop">
              <Button variant="outline-primary">
                Voir tout
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product, idx) => (
              <ProductCard 
                key={product.id} 
                product={product}
                className="animate-slide-up"
                style={{ animationDelay: `${idx * 100}ms` } as React.CSSProperties}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 md:py-24 bg-background">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">
              Pourquoi Nous Choisir?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Votre satisfaction est notre priorité
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Award, title: 'Qualité Premium', desc: 'Cheveux 100% naturels et fibres de haute qualité' },
              { icon: Truck, title: 'Livraison Rapide', desc: 'Livraison partout au Togo en 24-72h' },
              { icon: Shield, title: 'Paiement Sécurisé', desc: 'Mobile Money, carte bancaire ou à la livraison' },
              { icon: Headphones, title: 'Service Client', desc: 'Assistance WhatsApp 7j/7' },
            ].map((item, idx) => (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-card shadow-card hover:shadow-card-hover transition-shadow text-center group"
              >
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <item.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="font-serif text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-4">
              Ce Que Disent Nos Clientes
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Rejoignez des centaines de femmes satisfaites
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, idx) => (
              <div
                key={testimonial.id}
                className="p-6 rounded-2xl bg-card shadow-card animate-slide-up"
                style={{ animationDelay: `${idx * 100}ms` }}
              >
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <span key={i} className="text-accent">★</span>
                  ))}
                </div>
                <p className="text-foreground mb-4 italic">"{testimonial.comment}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-primary font-semibold">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-foreground text-background">
        <div className="container text-center">
          <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">
            Prête à Transformer Votre Look?
          </h2>
          <p className="text-background/70 max-w-2xl mx-auto mb-8">
            Découvrez notre collection et trouvez la perruque parfaite pour sublimer votre beauté naturelle
          </p>
          <Link to="/shop">
            <Button variant="hero" size="xl">
              Explorer la Boutique
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Index;
