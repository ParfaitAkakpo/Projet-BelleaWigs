import { Link } from 'react-router-dom';
import { ShoppingBag, Heart, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Product, formatPrice } from '@/data/products';
import { useCart } from '@/contexts/CartContext';
import { cn } from '@/lib/utils';

interface ProductCardProps extends React.HTMLAttributes<HTMLDivElement> {
  product: Product;
}

const ProductCard = ({ product, className, ...props }: ProductCardProps) => {
  const { addToCart } = useCart();

  return (
    <div className={cn("group relative bg-card rounded-xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300", className)} {...props}>
      {/* Image */}
      <Link to={`/product/${product.id}`} className="block relative aspect-[3/4] overflow-hidden bg-muted">
        <img
          src={product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.originalPrice && (
            <span className="px-2 py-1 text-xs font-semibold bg-primary text-primary-foreground rounded">
              -{Math.round((1 - product.price / product.originalPrice) * 100)}%
            </span>
          )}
          {!product.inStock && (
            <span className="px-2 py-1 text-xs font-semibold bg-destructive text-destructive-foreground rounded">
              Rupture
            </span>
          )}
        </div>

        {/* Wishlist */}
        <button className="absolute top-3 right-3 p-2 rounded-full bg-background/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-background">
          <Heart className="h-4 w-4 text-foreground" />
        </button>

        {/* Quick Add */}
        <div className="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="elegant"
            size="sm"
            className="w-full"
            onClick={(e) => {
              e.preventDefault();
              addToCart(product);
            }}
            disabled={!product.inStock}
          >
            <ShoppingBag className="h-4 w-4" />
            Ajouter au panier
          </Button>
        </div>
      </Link>

      {/* Info */}
      <div className="p-4 space-y-2">
        <Link to={`/product/${product.id}`}>
          <h3 className="font-medium text-foreground line-clamp-1 hover:text-primary transition-colors">
            {product.name}
          </h3>
        </Link>
        
        <div className="flex items-center gap-1">
          <Star className="h-3.5 w-3.5 fill-accent text-accent" />
          <span className="text-xs text-muted-foreground">
            {product.rating} ({product.reviewCount} avis)
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="font-semibold text-foreground">{formatPrice(product.price)}</span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through">
              {formatPrice(product.originalPrice)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
