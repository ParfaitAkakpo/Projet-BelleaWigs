// @ts-nocheck

import { useEffect, useState, useCallback } from 'react';

import { supabase } from '@/integrations/supabase/client';

import { Database } from '@/integrations/supabase/types';

import { Product, ProductVariant } from '@/types/product';
 
export type ProductInsert = Database['public']['Tables']['product']['Insert'];

export type ProductUpdate = Database['public']['Tables']['product']['Update'];
 
/**

* 🔹 Normalise les produits pour que `price` soit toujours défini

*/

function normalizeProducts(rows: any[]): Product[] {

  return (rows || []).map((row) => {

    const basePriceMin = (row as any).base_price_min;

    const existingPrice = (row as any).price;
 
    return {

      ...row,

      price:

        typeof existingPrice === 'number'

          ? existingPrice

          : typeof basePriceMin === 'number'

          ? basePriceMin

          : 0,

    } as Product;

  });

}
 
/**

* 🔹 Récupère la liste des produits (table `product`)

*/

export function useProducts() {

  const [data, setData] = useState<Product[]>([]);

  const [isLoading, setIsLoading] = useState(true);

  const [error, setError] = useState<string | null>(null);
 
  const fetchProducts = useCallback(async () => {

    try {

      setIsLoading(true);

      setError(null);
 
      const { data: products, error: fetchError } = await supabase

        .from('product') // ✅ nom réel

        .select('*')

        .eq('is_active', true);
 
      if (fetchError) {

        setError(fetchError.message);

        return;

      }
 
      const normalized = normalizeProducts(products || []);

      setData(normalized);

    } catch (err) {

      setError(err instanceof Error ? err.message : 'Erreur inconnue');

    } finally {

      setIsLoading(false);

    }

  }, []);
 
  useEffect(() => {

    fetchProducts();

  }, [fetchProducts]);
 
  return { data, isLoading, error, refetch: fetchProducts };

}
 
/**

* 🔹 Création de produit

*/

export function useCreateProduct() {

  const [isLoading, setIsLoading] = useState(false);

  const [error, setError] = useState<string | null>(null);
 
  const create = useCallback(async (product: ProductInsert) => {

    try {

      setIsLoading(true);

      setError(null);
 
      const { data, error: createError } = await supabase

        .from('product')

        .insert([product])

        .select()

        .single();
 
      if (createError) {

        setError(createError.message);

        return null;

      }
 
      const [normalized] = normalizeProducts([data]);

      return normalized;

    } catch (err) {

      const message = err instanceof Error ? err.message : 'Erreur inconnue';

      setError(message);

      return null;

    } finally {

      setIsLoading(false);

    }

  }, []);
 
  return { create, isLoading, error };

}
 
/**

* 🔹 Update produit

*/

export function useUpdateProduct() {

  const [isLoading, setIsLoading] = useState(false);

  const [error, setError] = useState<string | null>(null);
 
  const update = useCallback(async (id: string, product: ProductUpdate) => {

    try {

      setIsLoading(true);

      setError(null);
 
      const { data, error: updateError } = await supabase

        .from('product')

        .update(product)

        .eq('id', id)

        .select()

        .single();
 
      if (updateError) {

        setError(updateError.message);

        return null;

      }
 
      const [normalized] = normalizeProducts([data]);

      return normalized;

    } catch (err) {

      const message = err instanceof Error ? err.message : 'Erreur inconnue';

      setError(message);

      return null;

    } finally {

      setIsLoading(false);

    }

  }, []);
 
  return { update, isLoading, error };

}
 
/**

* 🔹 Suppression produit

*/

export function useDeleteProduct() {

  const [isLoading, setIsLoading] = useState(false);

  const [error, setError] = useState<string | null>(null);
 
  const deleteProduct = useCallback(async (id: string) => {

    try {

      setIsLoading(true);

      setError(null);
 
      const { error: deleteError } = await supabase

        .from('product')

        .delete()

        .eq('id', id);
 
      if (deleteError) {

        setError(deleteError.message);

        return false;

      }
 
      return true;

    } catch (err) {

      const message = err instanceof Error ? err.message : 'Erreur inconnue';

      setError(message);

      return false;

    } finally {

      setIsLoading(false);

    }

  }, []);
 
  return { delete: deleteProduct, isLoading, error };

}
 
/**

* 🔹 Variantes d'un produit (table `product_variant` + jointures)

*/

export function useProductVariants(productId?: string) {

  const [data, setData] = useState<ProductVariant[]>([]);

  const [isLoading, setIsLoading] = useState(true);

  const [error, setError] = useState<string | null>(null);
 
  useEffect(() => {

    if (!productId) {

      setData([]);

      setIsLoading(false);

      return;

    }
 
    const fetchVariants = async () => {

      try {

        setIsLoading(true);

        setError(null);
 
        const { data: rows, error: fetchError } = await supabase

          .from('product_variant') // ✅ nom réel

          .select(`

            id,

            product_id,

            price,

            stock,

            sku,

            is_active,

            product_colors (

              id,

              is_default,

              colors (

                id,

                name,

                hex_code

              ),

              product_color_images (

                image_url,

                position

              )

            ),

            lengths (

              id,

              value,

              unit

            )

          `)

          .eq('product_id', productId)

          .eq('is_active', true);
 
        if (fetchError) {

          setError(fetchError.message);

          return;

        }
 
        const formatted: ProductVariant[] = (rows || []).map((row: any) => {

          const pc = row.product_colors;

          const color = pc?.colors;

          const length = row.lengths;
 
          const medias =

            (pc?.product_color_images || [])

              .sort(

                (a: any, b: any) =>

                  (a.position ?? 0) - (b.position ?? 0)

              )

              .map((img: any) => img.image_url) || [];
 
          return {

            id: String(row.id),

            product_id: String(row.product_id),

            color: color?.name || '',

            color_hex: color?.hex_code || undefined,

            length: length?.value || 0,

            price: Number(row.price),

            stock_count: row.stock ?? 0,

            sku: row.sku,

            image_url: medias[0] || null,

            medias,

            is_active: row.is_active,

          };

        });
 
        setData(formatted);

      } catch (err) {

        setError(err instanceof Error ? err.message : 'Erreur inconnue');

      } finally {

        setIsLoading(false);

      }

    };
 
    fetchVariants();

  }, [productId]);
 
  return { data, isLoading, error };

}
 
/**

* 🔹 Upload image produit (bucket `product-images`)

*/

export async function uploadProductImage(

  file: File,

  productId?: string

): Promise<string | null> {

  try {

    const fileName = `${Date.now()}-${file.name}`;

    const path = productId ? `products/${productId}/${fileName}` : `products/${fileName}`;
 
    const { data, error } = await supabase.storage

      .from('product-images')

      .upload(path, file);
 
    if (error) {

      console.error('Upload error:', error);

      return null;

    }
 
    const { data: publicData } = supabase.storage

      .from('product-images')

      .getPublicUrl(data.path);
 
    return publicData.publicUrl;

  } catch (err) {

    console.error('Upload failed:', err);

    return null;

  }

}

 