// src/hooks/useProductDetail.ts

import { useEffect, useState } from "react";

import { supabase } from "@/integrations/supabase/client";

import type { Product, ProductVariant } from "@/types/product";
 
type Color = { id: number; name: string; hex_code: string | null };

type ProductColor = { id: number; product_id: number; color_id: number; is_default: boolean };

type Image = { product_color_id: number; image_url: string; position: number };

type Length = { id: number; value: number; unit: string };
 
export function useProductDetail(productId?: string) {

  const [product, setProduct] = useState<Product | null>(null);

  const [variants, setVariants] = useState<ProductVariant[]>([]);

  const [colors, setColors] = useState<Color[]>([]);

  const [imagesByColor, setImagesByColor] = useState<Record<number, string[]>>({});

  const [lengthsByColor, setLengthsByColor] = useState<Record<number, Length[]>>({});

  const [isLoading, setIsLoading] = useState(true);

  const [error, setError] = useState<string | null>(null);
 
  useEffect(() => {

    if (!productId) return;
 
    const fetchAll = async () => {

      try {

        setIsLoading(true);
 
        /** 1️⃣ Produit */

        const { data: productData, error: productErr } = await supabase

          .from("products")

          .select("*")

          .eq("id", productId)

          .single();
 
        if (productErr) throw productErr;

        setProduct(productData);
 
        /** 2️⃣ Variantes */

        const { data: variantData, error: variantErr } = await supabase

          .from("product_variant")

          .select(`

            *,

            product_colors!inner (

              id,

              color_id,

              is_default

            ),

            lengths!inner (

              id,

              value,

              unit

            )

          `)

          .eq("product_id", productId);
 
        if (variantErr) throw variantErr;
 
        // Convertir proprement pour le front

        const formattedVariants: ProductVariant[] = variantData.map((v: any) => ({

          id: v.id,

          product_id: v.product_id,

          product_color_id: v.product_colors.id,

          color_id: v.product_colors.color_id,

          length_id: v.lengths.id,

          length: v.lengths.value,

          color: "", // on va compléter après

          price: v.price,

          stock_count: v.stock,

          sku: v.sku,

          is_active: v.is_active,

        }));
 
        setVariants(formattedVariants);
 
        /** 3️⃣ Récupérer couleurs */

        const colorIds = [...new Set(variantData.map((v: any) => v.product_colors.color_id))];

        const { data: colorData, error: colorErr } = await supabase

          .from("colors")

          .select("*")

          .in("id", colorIds);
 
        if (colorErr) throw colorErr;
 
        setColors(colorData);
 
        // Injecter le nom de la couleur dans chaque variante

        formattedVariants.forEach((v) => {

          const color = colorData.find((c) => c.id === v.color_id);

          if (color) v.color = color.name;

        });
 
        /** 4️⃣ Récupérer images par couleur */

        const { data: productColorLinks } = await supabase

          .from("product_colors")

          .select("*")

          .eq("product_id", productId);
 
        const productColorIds = productColorLinks.map((pc) => pc.id);
 
        const { data: imageData } = await supabase

          .from("product_color_images")

          .select("*")

          .in("product_color_id", productColorIds)

          .order("position", { ascending: true });
 
        const groupedImages: Record<number, string[]> = {};

        imageData?.forEach((img: any) => {

          groupedImages[img.product_color_id] = groupedImages[img.product_color_id] || [];

          groupedImages[img.product_color_id].push(img.image_url);

        });
 
        setImagesByColor(groupedImages);
 
        /** 5️⃣ Longueurs par couleur */

        const lengthGroups: Record<number, Length[]> = {};
 
        variantData.forEach((v: any) => {

          const pcId = v.product_colors.id;

          const len: Length = v.lengths;

          lengthGroups[pcId] = lengthGroups[pcId] || [];

          if (!lengthGroups[pcId].some((l) => l.id === len.id)) {

            lengthGroups[pcId].push(len);

          }

        });
 
        setLengthsByColor(lengthGroups);

      } catch (err: any) {

        setError(err.message || "Erreur inconnue");

      } finally {

        setIsLoading(false);

      }

    };
 
    fetchAll();

  }, [productId]);
 
  return { product, variants, colors, imagesByColor, lengthsByColor, isLoading, error };

}

 