import { useState, useEffect, useRef, useMemo } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Search, X, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { formatPrice } from '@/lib/formatPrice';
import { useProducts } from '@/hooks/useProducts';
import { cn } from '@/lib/utils';
import { Product } from '@/types/product';

interface SearchAutocompleteProps {
  onClose?: () => void;
  className?: string;
  inputClassName?: string;
  showCloseButton?: boolean;
  autoFocus?: boolean;
}

const SearchAutocomplete = ({
  onClose,
  className,
  inputClassName,
  showCloseButton = true,
  autoFocus = true,
}: SearchAutocompleteProps) => {
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);

  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const { data: dbProducts, isLoading } = useProducts();

  const allProducts: Product[] = useMemo(
    () => dbProducts ?? [],
    [dbProducts]
  );

  // ✅ PRIX DEPUIS LE PRODUIT
  const getProductPrice = (product: Product) => {
    return product.price || 0;
  };

  const suggestions = useMemo(() => {
    if (!query.trim() || query.length < 2) return [];

    const words = query.toLowerCase().split(/\s+/);

    return allProducts
      .filter(product => {
        const searchableText = [
          product.name,
          product.description ?? '',
          product.category.replace(/-/g, ' ')
        ]
          .join(' ')
          .toLowerCase();

        return words.every(word => searchableText.includes(word));
      })
      .slice(0, 6);
  }, [query, allProducts]);

  // Submit recherche
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    navigate(`/shop?q=${encodeURIComponent(query.trim())}`);
    setQuery('');
    setIsFocused(false);
    onClose?.();
  };

  // Click suggestion
  const handleSuggestionClick = (productId: string) => {
    navigate(`/product/${productId}`);
    setQuery('');
    setIsFocused(false);
    onClose?.();
  };

  // Navigation clavier
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev =>
        prev < suggestions.length - 1 ? prev + 1 : prev
      );
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev > 0 ? prev - 1 : -1));
    } else if (e.key === 'Enter' && selectedIndex >= 0) {
      e.preventDefault();
      handleSuggestionClick(suggestions[selectedIndex].id);
    } else if (e.key === 'Escape') {
      setIsFocused(false);
      onClose?.();
    }
  };

  useEffect(() => {
    setSelectedIndex(-1);
  }, [suggestions]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        containerRef.current &&
        !containerRef.current.contains(e.target as Node)
      ) {
        setIsFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () =>
      document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const showSuggestions =
    isFocused && query.length >= 2 && (suggestions.length > 0 || isLoading);

  return (
    <div ref={containerRef} className={cn('relative', className)}>
      <form onSubmit={handleSubmit} className="flex items-center gap-2">
        <div className="relative flex-1">
          <Input
            ref={inputRef}
            type="text"
            placeholder="Rechercher perruque, mèche, couleur..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onKeyDown={handleKeyDown}
            className={cn('pr-10', inputClassName)}
            autoFocus={autoFocus}
          />

          {isLoading && query.length >= 2 && (
            <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
          )}
        </div>

        <Button type="submit" size="icon" variant="ghost">
          <Search className="h-5 w-5" />
        </Button>

        {showCloseButton && (
          <Button
            type="button"
            size="icon"
            variant="ghost"
            onClick={onClose}
          >
            <X className="h-5 w-5" />
          </Button>
        )}
      </form>

      {showSuggestions && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-background border border-border rounded-lg shadow-lg z-[100] overflow-hidden">
          {suggestions.length > 0 ? (
            <>
              <ul className="max-h-80 overflow-y-auto">
                {suggestions.map((product, index) => (
                  <li key={product.id}>
                    <button
                      type="button"
                      onClick={() =>
                        handleSuggestionClick(product.id)
                      }
                      className={cn(
                        'w-full flex items-center gap-3 p-3 text-left hover:bg-muted',
                        selectedIndex === index && 'bg-muted'
                      )}
                    >
                      <img
                        src={product.images?.[0] || product.image_url || '/placeholder.svg'}
                        alt={product.name}
                        className="w-12 h-12 object-cover rounded-md bg-muted"
                      />

                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">
                          {product.name}
                        </p>
                        <p className="text-xs text-muted-foreground truncate">
                          {product.category.replace(/-/g, ' ')}
                        </p>
                        <p className="text-sm font-semibold text-primary">
                          {formatPrice(getProductPrice(product))}
                        </p>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>

              <Link
                to={`/shop?q=${encodeURIComponent(query.trim())}`}
                onClick={() => {
                  setQuery('');
                  setIsFocused(false);
                  onClose?.();
                }}
                className="block p-3 text-center text-sm text-primary font-medium border-t border-border hover:bg-muted"
              >
                Voir tous les résultats →
              </Link>
            </>
          ) : (
            <div className="p-4 text-center text-muted-foreground">
              Recherche…
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SearchAutocomplete;