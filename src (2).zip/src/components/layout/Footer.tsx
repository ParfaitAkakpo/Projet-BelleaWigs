import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, MessageCircle } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-foreground text-background">
      <div className="container py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">

          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="inline-block">
              <span className="font-serif text-2xl font-bold">
                Belléa<span className="text-primary">Wigs</span>
              </span>
            </Link>
            <p className="text-sm text-background/70 leading-relaxed">
              Votre destination premium pour des perruques et mèches de qualité au Togo et au Bénin.
              Beauté, élégance et confiance.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-background/70 hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-background/70 hover:text-primary transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-background/70 hover:text-primary transition-colors">
                <MessageCircle className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-serif text-lg font-semibold">Liens Rapides</h4>
            <ul className="space-y-2">
              {[
                'Boutique',
                'Perruques Naturelles',
                'Perruques Synthétiques',
                'Mèches Naturelles',
                'Mèches Synthétiques',
                'Mon Compte'
              ].map((item) => (
                <li key={item}>
                  <Link
                    to="/shop"
                    className="text-sm text-background/70 hover:text-primary transition-colors"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Policies */}
          <div className="space-y-4">
            <h4 className="font-serif text-lg font-semibold">Informations</h4>
            <ul className="space-y-2">
              {[
                'Livraison',
                'Retours et Remboursements',
                'Guide des Tailles',
                'Entretien des Perruques',
                'FAQ'
              ].map((item) => (
                <li key={item}>
                  <Link
                    to="#"
                    className="text-sm text-background/70 hover:text-primary transition-colors"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h4 className="font-serif text-lg font-semibold">Contact</h4>
            <ul className="space-y-3">

              {/* Téléphone */}
              
               <li className="flex items-center gap-3 text-sm text-background/70">
                <Phone className="h-4 w-4 text-primary" />
                <span>+228 90 00 00 00 (Togo) / +229 66 00 00 00 (Bénin)</span>
              </li>

              {/* WhatsApp */}
              
               <li className="flex items-center gap-3 text-sm text-background/70">
                <MessageCircle className="h-4 w-4 text-primary" />
                <span>WhatsApp: +228 90 00 00 00 / +229 66 00 00 00 </span>
              </li>

              {/* Email */}
              <li className="flex items-center gap-3 text-sm text-background/70">
                <Mail className="h-4 w-4 text-primary" />
                <span>contact@belleawigs.com</span>
              </li>

              {/* Adresse */}
             

                <li className="flex items-start gap-3 text-sm text-background/70">
                <MapPin className="h-4 w-4 text-primary mt-0.5" />
                <span>Lomé, Togo<br />Abomey-Calavi, Bénin</span>
              </li>

            </ul>
          </div>

        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-background/10">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-background/50">
              © 2026 BelléaWigs. Tous droits réservés.
            </p>
            <div className="flex items-center gap-6">
              <img src="/placeholder.svg" alt="Flooz" className="h-6 opacity-70" />
              <img src="/placeholder.svg" alt="Mixx" className="h-6 opacity-70" />
              <img src="/placeholder.svg" alt="Visa" className="h-6 opacity-70" />
              <img src="/placeholder.svg" alt="Mastercard" className="h-6 opacity-70" />
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
};

export default Footer;
