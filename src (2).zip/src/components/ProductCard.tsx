import { Link } from 'react-router-dom';

import { Eye, Star } from 'lucide-react';

import { Button } from '@/components/ui/button';

import { Product, ProductVariant } from '@/types/product';

import { cn } from '@/lib/utils';

import { formatPrice } from '@/lib/formatPrice';
 
interface ProductCardProps extends React.HTMLAttributes<HTMLDivElement> {

  product: Product;

}
 
const ProductCard = ({ product, className, ...props }: ProductCardProps) => {

  // Labels lisibles pour les catégories

  const categoryLabels: Record<string, string> = {

    'natural-wigs': 'Perruque naturelle',

    'synthetic-wigs': 'Perruque synthétique',

    'natural-weaves': 'Mèche naturelle',

    'synthetic-weaves': 'Mèche synthétique',

  };
 
  /**

   * 🔥 Calcul du prix minimum

   *

   * 1. Si le produit a des variantes → min des prix des variantes

   * 2. Sinon, si base_price_min existe → base_price_min

   * 3. Sinon → price

   */

  let minPrice: number;
 
  if (Array.isArray(product.variants) && product.variants.length > 0) {

    minPrice = Math.min(

      ...product.variants.map((v: ProductVariant) => Number(v.price))

    );

  } else if (typeof product.base_price_min === 'number') {

    minPrice = Number(product.base_price_min);

  } else {

    minPrice = Number(product.price || 0);

  }
 
  // Promo si original_price > minPrice

  const hasSale =

    typeof product.original_price === 'number' &&

    product.original_price > minPrice;
 
  return (
<div

      className={cn(

        'group relative bg-card rounded-xl overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-300 flex flex-col',

        className

      )}

      {...props}
>

      {/* Image - lien vers détails */}
<Link

        to={`/product/${product.id}`}

        className="block relative aspect-[3/4] overflow-hidden bg-muted"
>
<img

          src={product.images?.[0] || product.image_url || '/placeholder.svg'}

          alt={product.name}

          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"

        />
 
        {/* Badges */}
<div className="absolute top-3 left-3 flex flex-col gap-2">

          {hasSale && product.original_price && (
<span className="px-2 py-1 text-xs font-semibold bg-primary text-primary-foreground rounded">

              -{Math.round((1 - minPrice / product.original_price) * 100)}%
</span>

          )}

          {product.in_stock === false && (
<span className="px-2 py-1 text-xs font-semibold bg-destructive text-destructive-foreground rounded">

              Rupture
</span>

          )}
</div>
</Link>
 
      {/* Infos */}
<div className="p-4 flex flex-col flex-grow space-y-3">

        {/* Catégorie */}
<span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">

          {product.category

            ? categoryLabels[product.category] ||

              product.category.replace(/-/g, ' ')

            : ''}
</span>
 
        {/* Nom produit */}
<Link to={`/product/${product.id}`}>
<h3 className="font-medium text-foreground line-clamp-2 hover:text-primary transition-colors min-h-[2.5rem]">

            {product.name}
</h3>
</Link>
 
        {/* Rating */}

        {typeof product.rating === 'number' && (
<div className="flex items-center gap-1">
<Star className="h-3.5 w-3.5 fill-accent text-accent" />
<span className="text-xs text-muted-foreground">

              {product.rating} ({product.review_count || 0} avis)
</span>
</div>

        )}
 
        {/* Prix */}
<div className="space-y-1">
<div className="flex items-center gap-2">
<span className="font-semibold text-foreground">

              {Array.isArray(product.variants) && product.variants.length > 0

                ? `À partir de ${formatPrice(minPrice)}`

                : formatPrice(minPrice)}
</span>
</div>

          {hasSale && product.original_price && (
<div className="text-sm text-muted-foreground line-through">

              {formatPrice(product.original_price)}
</div>

          )}
</div>
 
        {/* Bouton "Voir les détails" */}
<div className="pt-2 mt-auto">
<Link to={`/product/${product.id}`} className="block">
<Button

              variant="outline"

              size="sm"

              className="w-full group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
>
<Eye className="h-4 w-4 mr-2" />

              Voir les détails
</Button>
</Link>
</div>
</div>
</div>

  );

};
 
export default ProductCard;

 