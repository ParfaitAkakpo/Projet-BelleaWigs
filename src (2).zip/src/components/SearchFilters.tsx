import { useProducts } from '@/hooks/useProducts';
import { Product } from '@/types/product';
import { useState, useMemo, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Grid3X3, LayoutList, Loader2, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ProductCard from '@/components/ProductCard';
import { categories } from '@/data/static';
import { cn } from '@/lib/utils';
import type { CSSProperties } from 'react';

// Filtrage avancé pour les filtres header (meches, perruques, promotions)
function getProductsByFilter(products: Product[], filter: string): Product[] {
  if (filter === 'meches') {
    // Toutes les catégories contenant 'weaves' (synthetic-weaves, natural-weaves, etc.)
    return products.filter((p) => {
      const cat = (p.category || '').toString().toLowerCase().replace(/\s|-/g, '');
      return cat.includes('weaves');
    });
  }

  if (filter === 'perruques') {
    // Toutes les catégories contenant 'wigs' (synthetic-wigs, natural-wigs, etc.)
    return products.filter((p) => {
      const cat = (p.category || '').toString().toLowerCase().replace(/\s|-/g, '');
      return cat.includes('wigs');
    });
  }

  if (filter === 'promotions') {
    // Tous les produits dont le prix originel est strictement supérieur au prix actuel
    return products.filter((p) => {
      const hasPromoPrice =
        typeof p.original_price === 'number' &&
        typeof p.price === 'number' &&
        p.original_price > p.price;

      return hasPromoPrice || !!p.is_promo;
    });
  }

  return products;
}

// Helper to convert DB product to static product format
const convertDbProduct = (dbProduct: Product): Product => ({
  ...dbProduct,
  images: dbProduct.images?.length ? dbProduct.images : ['/placeholder.svg'],
  details: dbProduct.details || [],
});

const Shop = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'rating' | 'newest'>('featured');
  const [gridView, setGridView] = useState<'grid' | 'list'>('grid');

  // Get global search query from URL
  const globalSearchQuery = searchParams.get('q') || '';

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState(globalSearchQuery);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedLengths, setSelectedLengths] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 150000]);
  const [inStockOnly, setInStockOnly] = useState(false);

  const { data: dbProducts = [], isLoading } = useProducts();

  const selectedCategory = searchParams.get('category') || 'all';
  const selectedFilter = searchParams.get('filter') || '';

  // Update search query when URL changes
  useEffect(() => {
    setSearchQuery(globalSearchQuery);
  }, [globalSearchQuery]);

  // Use DB products if available
  const allProducts = useMemo<Product[]>(() => {
    if (dbProducts && dbProducts.length > 0) {
      return dbProducts.map(convertDbProduct);
    }
    return [];
  }, [dbProducts]);

  // Calculate max price for slider
  const maxPrice = useMemo(() => {
    if (!allProducts.length) return 150000;
    const max = Math.max(...allProducts.map((p) => p.price || 0), 150000);
    return max;
  }, [allProducts]);

  const filteredProducts = useMemo(() => {
    let result: Product[] = [...allProducts];

    // Apply header filter (Mèches, Perruques, Promotions)
    if (selectedFilter) {
      result = getProductsByFilter(result, selectedFilter);
    }

    // Category filter
    if (selectedCategory !== 'all') {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // Search query filter - search in name, description, details, category
    if (searchQuery.trim()) {
      const queryWords = searchQuery.toLowerCase().trim().split(/\s+/);
      result = result.filter((p) => {
        const searchableText = [
          p.name,
          p.description,
          p.category.replace(/-/g, ' '),
          ...(p.details || []),
        ]
          .join(' ')
          .toLowerCase();

        return queryWords.every((word) => searchableText.includes(word));
      });
    }

    // Price range filter
    result = result.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    );

    // In stock filter
    if (inStockOnly) {
      result = result.filter((p) => p.in_stock);
    }

    // Color filter (dans les détails – en attendant meilleur système par variantes)
    if (selectedColors.length > 0) {
      result = result.filter((p) => {
        const detailsText = p.details?.join(' ').toLowerCase() || '';
        return selectedColors.some((color) => detailsText.includes(color));
      });
    }

    // Length filter (dans les détails – en attendant meilleur système)
    if (selectedLengths.length > 0) {
      result = result.filter((p) => {
        const detailsText = p.details?.join(' ').toLowerCase() || '';
        return selectedLengths.some(
          (length) =>
            detailsText.includes(length + 'cm') ||
            detailsText.includes(length + ' pouces')
        );
      });
    }

    // Sorting
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 'newest':
        // Si tu as une vraie date, remplace b.id.localeCompare par created_at
        result.sort((a, b) => b.id.localeCompare(a.id));
        break;
      case 'featured':
      default:
        result.sort(
          (a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0)
        );
    }

    return result;
  }, [
    allProducts,
    selectedCategory,
    selectedFilter,
    sortBy,
    searchQuery,
    priceRange,
    inStockOnly,
    selectedColors,
    selectedLengths,
  ]);

  const getPageTitle = () => {
    if (searchQuery.trim()) {
      return `Résultats pour "${searchQuery.trim()}"`;
    }

    if (selectedFilter === 'meches') return 'Toutes les Mèches';
    if (selectedFilter === 'perruques') return 'Toutes les Perruques';
    if (selectedFilter === 'promotions') return 'Promotions';

    if (selectedCategory !== 'all') {
      const cat = categories.find((c) => c.id === selectedCategory);
      return cat?.name || 'Boutique';
    }

    return 'Tous les Produits';
  };

  const handleCategoryClick = (categoryId: string) => {
    const newParams = new URLSearchParams();
    if (categoryId !== 'all') {
      newParams.set('category', categoryId);
    }
    setSearchParams(newParams);
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedColors([]);
    setSelectedLengths([]);
    setPriceRange([0, maxPrice]);
    setInStockOnly(false);
    const newParams = new URLSearchParams(searchParams);
    newParams.delete('q');
    setSearchParams(newParams);
  };

  const isPromotionsPage = selectedFilter === 'promotions';
  const hasNoPromotions = isPromotionsPage && filteredProducts.length === 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-muted/30 py-8 md:py-12">
        <div className="container">
          <div className="flex items-center gap-3 mb-2">
            {isPromotionsPage && <Tag className="h-6 w-6 text-primary" />}
            <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground">
              {getPageTitle()}
            </h1>
          </div>
          <p className="text-muted-foreground">
            {isLoading
              ? 'Chargement...'
              : `${filteredProducts.length} produit${
                  filteredProducts.length > 1 ? 's' : ''
                } trouvé${filteredProducts.length > 1 ? 's' : ''}`}
          </p>
        </div>
      </div>

      <div className="container py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar Filters - Desktop */}
          <aside className="hidden lg:block w-72 shrink-0">
            <div className="sticky top-24 space-y-6">
              <div>
                <h3 className="font-semibold text-foreground mb-4">
                  Catégories
                </h3>
                <div className="space-y-2">
                  <button
                    onClick={() => handleCategoryClick('all')}
                    className={cn(
                      'block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors',
                      selectedCategory === 'all' && !selectedFilter
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:bg-muted'
                    )}
                  >
                    Tous les Produits
                  </button>
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => handleCategoryClick(cat.id)}
                      className={cn(
                        'block w-full text-left px-3 py-2 rounded-lg text-sm transition-colors',
                        selectedCategory === cat.id
                          ? 'bg-primary text-primary-foreground'
                          : 'text-muted-foreground hover:bg-muted'
                      )}
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <div className="flex-1">
            {/* Mobile Categories */}
            <div className="lg:hidden mb-6 overflow-x-auto">
              <div className="flex gap-2 pb-2">
                <button
                  onClick={() => handleCategoryClick('all')}
                  className={cn(
                    'px-3 py-1.5 rounded-full text-sm whitespace-nowrap transition-colors',
                    selectedCategory === 'all' && !selectedFilter
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  )}
                >
                  Tous
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => handleCategoryClick(cat.id)}
                    className={cn(
                      'px-3 py-1.5 rounded-full text-sm whitespace-nowrap transition-colors',
                      selectedCategory === cat.id
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-muted-foreground'
                    )}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-6 border-b border-border">
              {/* Sort */}
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground hidden sm:inline">
                  Trier par:
                </span>
                <div className="relative">
                  <select
                    value={sortBy}
                    onChange={(e) =>
                      setSortBy(e.target.value as typeof sortBy)
                    }
                    className="appearance-none bg-background border border-input rounded-lg px-4 py-2 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="featured">Populaires</option>
                    <option value="newest">Nouveautés</option>
                    <option value="price-low">Prix croissant</option>
                    <option value="price-high">Prix décroissant</option>
                    <option value="rating">Meilleures notes</option>
                  </select>
                </div>
              </div>

              {/* View Toggle */}
              <div className="flex items-center gap-1 border border-input rounded-lg p-1">
                <button
                  onClick={() => setGridView('grid')}
                  className={cn(
                    'p-2 rounded transition-colors',
                    gridView === 'grid'
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-muted'
                  )}
                >
                  <Grid3X3 className="h-4 w-4" />
                </button>
                <button
                  onClick={() => setGridView('list')}
                  className={cn(
                    'p-2 rounded transition-colors',
                    gridView === 'list'
                      ? 'bg-primary text-primary-foreground'
                      : 'text-muted-foreground hover:bg-muted'
                  )}
                >
                  <LayoutList className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="flex items-center justify-center py-16">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            )}

            {/* No Promotions */}
            {!isLoading && hasNoPromotions && (
              <div className="text-center py-16 px-4">
                <Tag className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">
                  Aucune promotion disponible pour le moment
                </h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  Revenez bientôt pour découvrir nos offres spéciales ! En
                  attendant, explorez notre collection complète.
                </p>
                <Button
                  variant="outline"
                  onClick={() => setSearchParams({})}
                >
                  Voir tous les produits
                </Button>
              </div>
            )}

            {/* Products Grid */}
            {!isLoading && filteredProducts.length > 0 ? (
              <div
                className={cn(
                  'grid gap-6',
                  gridView === 'grid'
                    ? 'grid-cols-1 sm:grid-cols-2 xl:grid-cols-3'
                    : 'grid-cols-1'
                )}
              >
                {filteredProducts.map((product, idx) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    className="animate-fade-in"
                    style={
                      { animationDelay: `${idx * 50}ms` } as CSSProperties
                    }
                  />
                ))}
              </div>
            ) : (
              !isLoading &&
              !hasNoPromotions && (
                <div className="text-center py-16">
                  <p className="text-muted-foreground mb-4">
                    Aucun produit trouvé.
                  </p>
                  <Button variant="outline" onClick={clearFilters}>
                    Effacer les filtres
                  </Button>
                </div>
              )
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Shop;
