import React from 'react';

interface MediaCarouselProps {
  medias: string[];
  selected: number;
  onSelect: (idx: number) => void;
}

function isVideo(url: string): boolean {
  return /\.(mp4|webm|ogg)$/i.test(url);
}

export const MediaCarousel: React.FC<MediaCarouselProps> = ({ medias, selected, onSelect }) => {
  if (!Array.isArray(medias) || medias.length === 0) {
    return (
      <div className="w-full h-64 flex items-center justify-center text-muted-foreground bg-muted rounded-xl">
        Pas d'image ou vidéo disponible
      </div>
    );
  }

  return (
    <div>
      <div className="aspect-square rounded-2xl overflow-hidden bg-muted mb-4 flex items-center justify-center">
        {isVideo(medias[selected]) ? (
          <video src={medias[selected]} controls className="w-full h-full object-cover" />
        ) : (
          <img src={medias[selected]} alt="media" className="w-full h-full object-cover" />
        )}
      </div>
      {medias.length > 1 && (
        <div className="flex gap-3 overflow-x-auto pb-2">
          {medias.map((media, idx) => (
            <button
              key={idx}
              onClick={() => onSelect(idx)}
              className={`w-16 h-16 rounded-lg overflow-hidden border-2 flex-shrink-0 transition-colors ${selected === idx ? 'border-primary' : 'border-transparent hover:border-primary/50'}`}
            >
              {isVideo(media) ? (
                <video src={media} className="w-full h-full object-cover" />
              ) : (
                <img src={media} alt="miniature" className="w-full h-full object-cover" />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
