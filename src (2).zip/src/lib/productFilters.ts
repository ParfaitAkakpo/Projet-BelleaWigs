import { Product } from '@/types/product';

export const getProductsByFilter = (
  productList: Product[],
  filter: string
): Product[] => {
  switch (filter) {
    case 'meches':
      return productList.filter(
        p =>
          p.category === 'natural-weaves' ||
          p.category === 'synthetic-weaves'
      );

    case 'perruques':
      return productList.filter(
        p =>
          p.category === 'natural-wigs' ||
          p.category === 'synthetic-wigs'
      );

    case 'promotions':
      return productList.filter(p => p.is_promo);

    default:
      return productList;
  }
};
