import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Package, 
  Plus, 
  Pencil, 
  Trash2, 
  LogOut,
  ImagePlus,
  X,
  Save,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useAdmin } from '@/hooks/useAdmin';
import { 
  useProducts, 
  useCreateProduct, 
  useUpdateProduct, 
  useDeleteProduct,
  uploadProductImage,
  ProductInsert
} from '@/hooks/useProducts';
import { Product } from '@/types/product';
import { categories } from '@/data/static';
import { formatPrice } from '@/lib/formatPrice';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { user, isAdmin, loading: authLoading, signOut } = useAdmin();
  const { data: products, isLoading } = useProducts();
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const deleteProduct = useDeleteProduct();

  const [showForm, setShowForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [uploading, setUploading] = useState(false);
  const [formData, setFormData] = useState<ProductInsert>({
    name: '',
    description: '',
    price: 0,
    original_price: null,
    category: 'natural-wigs',
    extension_type: null,
    images: [],
    in_stock: true,
    stock_count: 0,
    featured: false,
    details: [],
  });
  const [newDetail, setNewDetail] = useState('');

  // Redirect if not admin
  if (!authLoading && (!user || !isAdmin)) {
    navigate('/admin/login');
    return null;
  }

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const handleLogout = async () => {
    await signOut();
    navigate('/admin/login');
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: 0,
      original_price: null,
      category: 'natural-wigs',
      extension_type: null,
      images: [],
      in_stock: true,
      stock_count: 0,
      featured: false,
      details: [],
    });
    setEditingProduct(null);
    setShowForm(false);
  };

  const handleEdit = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description,
      price: product.price,
      original_price: product.original_price,
      category: product.category,
      extension_type: product.extension_type as any,
      images: product.images || [],
      in_stock: product.in_stock,
      stock_count: product.stock_count,
      featured: product.featured,
      details: product.details || [],
    });
    setShowForm(true);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);
    try {
      const uploadPromises = Array.from(files).map(file => uploadProductImage(file));
      const urls = await Promise.all(uploadPromises);
      setFormData(prev => ({
        ...prev,
        images: [...(prev.images || []), ...urls],
      }));
    } catch (error) {
      console.error('Upload error:', error);
    }
    setUploading(false);
  };

  const removeImage = (index: number) => {
    setFormData(prev => ({
      ...prev,
      images: prev.images?.filter((_, i) => i !== index) || [],
    }));
  };

  const addDetail = () => {
    if (newDetail.trim()) {
      setFormData(prev => ({
        ...prev,
        details: [...(prev.details || []), newDetail.trim()],
      }));
      setNewDetail('');
    }
  };

  const removeDetail = (index: number) => {
    setFormData(prev => ({
      ...prev,
      details: prev.details?.filter((_, i) => i !== index) || [],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingProduct) {
      await updateProduct.update(editingProduct.id, formData);
    } else {
      await createProduct.create(formData);
    }
    
    resetForm();
  };

  const handleDelete = async (id: string) => {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')) {
      await deleteProduct.delete(id);
    }
  };

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-50">
        <div className="container py-4 flex items-center justify-between">
          <h1 className="font-serif text-xl font-bold text-foreground">
            Administration EloriaHair
          </h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">{user?.email}</span>
            <Button variant="outline" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Déconnexion
            </Button>
          </div>
        </div>
      </header>

      <div className="container py-8">
        {/* Actions */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <Package className="h-6 w-6 text-primary" />
            <h2 className="font-serif text-2xl font-bold">Produits</h2>
            <span className="text-muted-foreground">({products?.length || 0})</span>
          </div>
          <Button onClick={() => setShowForm(true)} variant="hero">
            <Plus className="h-4 w-4 mr-2" />
            Nouveau Produit
          </Button>
        </div>

        {/* Product Form Modal */}
        {showForm && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-start justify-center overflow-y-auto py-8">
            <div className="bg-card rounded-2xl shadow-xl w-full max-w-2xl mx-4 p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-serif text-xl font-bold">
                  {editingProduct ? 'Modifier le produit' : 'Nouveau produit'}
                </h3>
                <button onClick={resetForm} className="text-muted-foreground hover:text-foreground">
                  <X className="h-6 w-6" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Images */}
                <div>
                  <label className="block text-sm font-medium mb-2">Images</label>
                  <div className="flex flex-wrap gap-3 mb-3">
                    {formData.images?.map((url, index) => (
                      <div key={index} className="relative w-20 h-20">
                        <img src={url} alt="" className="w-full h-full object-cover rounded-lg" />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute -top-2 -right-2 bg-destructive text-destructive-foreground rounded-full p-1"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                    <label className="w-20 h-20 border-2 border-dashed border-border rounded-lg flex items-center justify-center cursor-pointer hover:border-primary transition-colors">
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleImageUpload}
                        className="hidden"
                        disabled={uploading}
                      />
                      {uploading ? (
                        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
                      ) : (
                        <ImagePlus className="h-6 w-6 text-muted-foreground" />
                      )}
                    </label>
                  </div>
                </div>

                {/* Name */}
                <div>
                  <label className="block text-sm font-medium mb-2">Nom du produit *</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    required
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-sm font-medium mb-2">Description *</label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    rows={3}
                    required
                  />
                </div>

                {/* Price & Original Price */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Prix (FCFA) *</label>
                    <Input
                      type="number"
                      value={formData.price}
                      onChange={(e) => setFormData(prev => ({ ...prev, price: parseInt(e.target.value) || 0 }))}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Prix original (optionnel)</label>
                    <Input
                      type="number"
                      value={formData.original_price || ''}
                      onChange={(e) => setFormData(prev => ({ ...prev, original_price: e.target.value ? parseInt(e.target.value) : null }))}
                    />
                  </div>
                </div>

                {/* Category & Extension Type */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Catégorie *</label>
                    <Select
                      value={formData.category}
                      onValueChange={(value: string) => setFormData(prev => ({ ...prev, category: value as any }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(cat => (
                          <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  {formData.category === 'extensions' && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Type de mèche</label>
                      <Select
                        value={formData.extension_type || ''}
                        onValueChange={(value: string) => setFormData(prev => ({ ...prev, extension_type: value as any }))}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Sélectionner..." />
                        </SelectTrigger>
                        <SelectContent>
                          {[
                            { id: 'clip-in', name: 'Clip-in' },
                            { id: 'tape-in', name: 'Tape-in' },
                          ].map(type => (
                            <SelectItem key={type.id} value={type.id}>
                              {type.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                {/* Stock */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Quantité en stock</label>
                    <Input
                      type="number"
                      value={formData.stock_count}
                      onChange={(e) => setFormData(prev => ({ ...prev, stock_count: parseInt(e.target.value) || 0 }))}
                    />
                  </div>
                  <div className="flex items-center gap-4 pt-6">
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={formData.in_stock}
                        onCheckedChange={(checked) => setFormData(prev => ({ ...prev, in_stock: checked }))}
                      />
                      <span className="text-sm">En stock</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={formData.featured}
                        onCheckedChange={(checked) => setFormData(prev => ({ ...prev, featured: checked }))}
                      />
                      <span className="text-sm">Mis en avant</span>
                    </div>
                  </div>
                </div>

                {/* Details */}
                <div>
                  <label className="block text-sm font-medium mb-2">Détails du produit</label>
                  <div className="flex gap-2 mb-2">
                    <Input
                      value={newDetail}
                      onChange={(e) => setNewDetail(e.target.value)}
                      placeholder="Ex: Longueur: 45cm"
                      onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addDetail())}
                    />
                    <Button type="button" variant="outline" onClick={addDetail}>
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {formData.details?.map((detail, index) => (
                      <span key={index} className="bg-muted px-3 py-1 rounded-full text-sm flex items-center gap-2">
                        {detail}
                        <button type="button" onClick={() => removeDetail(index)}>
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                </div>

                {/* Submit */}
                <div className="flex gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                    Annuler
                  </Button>
                  <Button 
                    type="submit" 
                    variant="hero" 
                    className="flex-1"
                    disabled={createProduct.isLoading || updateProduct.isLoading}
                  >
                    {(createProduct.isLoading || updateProduct.isLoading) ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Save className="h-4 w-4 mr-2" />
                    )}
                    {editingProduct ? 'Mettre à jour' : 'Créer'}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Products Table */}
        <div className="bg-card rounded-xl border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-4 font-medium">Image</th>
                  <th className="text-left p-4 font-medium">Nom</th>
                  <th className="text-left p-4 font-medium">Catégorie</th>
                  <th className="text-left p-4 font-medium">Prix</th>
                  <th className="text-left p-4 font-medium">Stock</th>
                  <th className="text-left p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {products?.map((product) => (
                  <tr key={product.id} className="border-t border-border hover:bg-muted/30">
                    <td className="p-4">
                      <img
                        src={product.images?.[0] || '/placeholder.svg'}
                        alt={product.name}
                        className="w-12 h-12 object-cover rounded-lg"
                      />
                    </td>
                    <td className="p-4">
                      <div className="font-medium">{product.name}</div>
                      {product.featured && (
                        <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded">
                          Vedette
                        </span>
                      )}
                    </td>
                    <td className="p-4 text-muted-foreground">
                      {categories.find(c => c.id === product.category)?.name}
                      {product.extension_type && (
                        <div className="text-xs">
                          {product.extension_type}
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="font-medium">{formatPrice(product.price)}</div>
                      {product.original_price && (
                        <div className="text-xs text-muted-foreground line-through">
                          {formatPrice(product.original_price)}
                        </div>
                      )}
                    </td>
                    <td className="p-4">
                      <span className={product.in_stock ? 'text-green-600' : 'text-red-600'}>
                        {product.stock_count} {product.in_stock ? '✓' : '✗'}
                      </span>
                    </td>
                    <td className="p-4">
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" onClick={() => handleEdit(product)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="text-destructive hover:bg-destructive hover:text-destructive-foreground"
                          onClick={() => handleDelete(product.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
                {(!products || products.length === 0) && (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-muted-foreground">
                      Aucun produit. Cliquez sur "Nouveau Produit" pour commencer.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
