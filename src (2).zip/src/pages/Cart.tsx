import { Link } from "react-router-dom";
import { Trash2, Minus, Plus, ShoppingBag, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { formatPrice } from "@/lib/formatPrice";

const Cart = () => {
  const { items, updateQuantity, removeFromCart, totalPrice, totalItems } = useCart();

  const deliveryFee = totalPrice >= 50000 ? 0 : 2000;
  const grandTotal = totalPrice + deliveryFee;

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container py-16 text-center">
          <div className="max-w-md mx-auto">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-muted flex items-center justify-center">
              <ShoppingBag className="h-10 w-10 text-muted-foreground" />
            </div>
            <h1 className="font-serif text-2xl font-bold text-foreground mb-4">Votre panier est vide</h1>
            <p className="text-muted-foreground mb-8">Découvrez notre collection de perruques et mèches de qualité</p>
            <Link to="/shop">
              <Button variant="hero" size="lg">
                Découvrir la Boutique
                <ArrowRight className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-8">
          Panier ({totalItems} article{totalItems > 1 ? "s" : ""})
        </h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {items.map((item) => {
              const variantImg =
                item.variant.image_url ||
                item.variant.medias?.[0] ||
                item.product.images?.[0] ||
                item.product.image_url ||
                "/placeholder.svg";

              return (
                <div
                  key={item.variant.id}
                  className="flex gap-4 p-4 bg-card rounded-xl shadow-card"
                >
                  <Link to={`/product/${item.product.id}`} className="shrink-0">
                    <img
                      src={variantImg}
                      alt={item.product.name}
                      className="w-24 h-24 md:w-32 md:h-32 rounded-lg object-cover"
                    />
                  </Link>

                  <div className="flex-1 min-w-0">
                    <Link to={`/product/${item.product.id}`}>
                      <h3 className="font-medium text-foreground hover:text-primary transition-colors line-clamp-1">
                        {item.product.name}
                      </h3>
                    </Link>

                    <p className="text-sm text-muted-foreground mt-1">
                      Couleur: <span className="font-medium">{item.variant.color}</span> • Longueur:{" "}
                      <span className="font-medium">{item.variant.length}"</span>
                    </p>

                    <p className="text-sm text-muted-foreground mt-1">
                      {formatPrice(item.variant.price)} / unité
                    </p>

                    <div className="flex items-center justify-between mt-4">
                      <div className="flex items-center border border-input rounded-lg">
                        <button
                          onClick={() => updateQuantity(item.variant.id, item.quantity - 1)}
                          className="p-2 hover:bg-muted transition-colors"
                        >
                          <Minus className="h-4 w-4" />
                        </button>

                        <span className="w-10 text-center text-sm font-medium">{item.quantity}</span>

                        <button
                          onClick={() => updateQuantity(item.variant.id, item.quantity + 1)}
                          className="p-2 hover:bg-muted transition-colors"
                        >
                          <Plus className="h-4 w-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-4">
                        <span className="font-semibold text-foreground">
                          {formatPrice(item.variant.price * item.quantity)}
                        </span>
                        <button
                          onClick={() => removeFromCart(item.variant.id)}
                          className="p-2 text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="sticky top-24 p-6 bg-card rounded-xl shadow-card space-y-4">
              <h3 className="font-serif text-xl font-semibold text-foreground">Résumé</h3>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Sous-total</span>
                  <span className="font-medium">{formatPrice(totalPrice)}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-muted-foreground">Livraison</span>
                  <span className="font-medium">
                    {deliveryFee === 0 ? <span className="text-green-600">Gratuite</span> : formatPrice(deliveryFee)}
                  </span>
                </div>

                {totalPrice < 50000 && (
                  <p className="text-xs text-muted-foreground">
                    Ajoutez {formatPrice(50000 - totalPrice)} pour la livraison gratuite
                  </p>
                )}

                <div className="h-px bg-border" />

                <div className="flex justify-between text-lg">
                  <span className="font-semibold">Total</span>
                  <span className="font-bold text-foreground">{formatPrice(grandTotal)}</span>
                </div>
              </div>

              <Link to="/checkout" className="block">
                <Button variant="hero" size="lg" className="w-full">
                  Passer la commande
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>

              <Link to="/shop" className="block">
                <Button variant="ghost" className="w-full">
                  Continuer mes achats
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
