import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Truck, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useCart } from "@/contexts/CartContext";
import { regions } from "@/data/static";
import { formatPrice } from "@/lib/formatPrice";
import { supabase } from "@/integrations/supabase/client";

const Checkout = () => {
  const navigate = useNavigate();
  const { items, totalPrice } = useCart();
  const [paymentMethod, setPaymentMethod] = useState<"mobile" | "card" | "cash">("mobile");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const deliveryFee = totalPrice >= 50000 ? 0 : 2000;
  const grandTotal = totalPrice + deliveryFee;

  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    email: "",
    country: "togo",
    region: "",
    city: "",
    address: "",
    notes: "",
  });

  const phoneCodes: Record<string, string> = {
    togo: "+228",
    benin: "+229",
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => {
      if (name === "country") return { ...prev, country: value, region: "" };
      return { ...prev, [name]: value };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Sécurité: pas de commande si variante manquante
    const invalid = items.some((i) => !i.variant?.id);
    if (invalid) {
      setIsSubmitting(false);
      alert("Erreur: une variante est manquante dans le panier. Merci de revenir au panier et réessayer.");
      return;
    }

    // 1) Créer la commande
    let order: any;
    try {
      const result = await supabase
        .from("orders")
        .insert({
          full_name: formData.fullName,
          phone: formData.phone,
          email: formData.email,
          country: formData.country,
          region: formData.region,
          city: formData.city,
          address: formData.address,
          notes: formData.notes,
          payment_method: paymentMethod,
          total: grandTotal,
          created_at: new Date().toISOString(),
        } as any)
        .select()
        .single();

      if (result.error || !result.data) throw new Error(result.error?.message || "Commande non créée");
      order = result.data;
    } catch (err) {
      console.error("Erreur lors de la création de la commande :", err);
      setIsSubmitting(false);
      alert("Erreur lors de la création de la commande. Merci de réessayer.");
      return;
    }

    // 2) Enregistrer les items (✅ item.variant)
    const orderItems = items.map((item) => ({
      order_id: order.id,
      product_id: item.product.id,
      variant_id: item.variant.id,
      color: item.variant.color,
      length: item.variant.length,
      quantity: item.quantity,
      unit_price: item.variant.price,
    }));

    try {
      const { error: itemsError } = await supabase.from("order_items").insert(orderItems as any);
      if (itemsError) throw new Error(itemsError.message);
    } catch (err) {
      console.error("Erreur lors de l’enregistrement des produits :", err);
      setIsSubmitting(false);
      alert("Erreur lors de l’enregistrement des produits. Merci de réessayer.");
      return;
    }

    // 3) Notif WhatsApp (garde ton code, juste le phone correct)
    try {
      await fetch("https://ccdefnjxrfcjsffrzrab.functions.supabase.co/notify_whatsapp2", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          record: {
            id: order.id,
            full_name: formData.fullName,
            phone: phoneCodes[formData.country] + formData.phone,
            total: grandTotal,
          },
        }),
      });
    } catch (smsError) {
      console.error("Erreur notify_whatsapp2 :", smsError);
    }

    setIsSubmitting(false);
    navigate("/order-confirmation");
  };

  // ... ton JSX existant (tu peux le laisser)
  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <button
          onClick={() => navigate("/cart")}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8 transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          Retour au panier
        </button>

        <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-8">
          Finaliser la commande
        </h1>

        <form onSubmit={handleSubmit}>
          {/* ... garde le reste de ta page */}
          <div className="p-6 bg-card rounded-xl shadow-card space-y-4">
            <h2 className="font-serif text-xl font-semibold text-foreground flex items-center gap-2">
              <Truck className="h-5 w-5 text-primary" />
              Adresse de livraison
            </h2>

            {/* ... */}
          </div>

          <div className="mt-6">
            <Button type="submit" variant="hero" size="lg" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? "Traitement..." : `Payer ${formatPrice(grandTotal)}`}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Checkout;
