// src/pages/ProductDetail.tsx

import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { Loader2, AlertCircle, Minus, Plus, ShoppingBag } from "lucide-react";

import { MediaCarousel } from "@/components/MediaCarousel";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";

import { useCart } from "@/contexts/CartContext";
import { useProducts, useProductVariants } from "@/hooks/useProducts";
import type { Product, ProductVariant } from "@/types/product";
import { formatPrice } from "@/lib/formatPrice";
import { cn } from "@/lib/utils";

type CarouselItem = {
  colorKey: string; // ex: "Noir"
  imageUrl: string;
};

export default function ProductDetail() {
  const { id } = useParams();
  const { addToCart } = useCart();

  const {
    data: products = [],
    isLoading: productsLoading,
    error: productsError,
  } = useProducts();

  const {
    data: variants = [],
    isLoading: variantsLoading,
    error: variantsError,
  } = useProductVariants(id);

  const product: Product | undefined = useMemo(
    () => products.find((p) => String(p.id) === String(id)),
    [products, id]
  );

  // Group variants by color
  const variantsByColor = useMemo(() => {
    const map: Record<string, ProductVariant[]> = {};
    for (const v of variants) {
      const key = v.color || "Autre";
      if (!map[key]) map[key] = [];
      map[key].push(v);
    }
    // sort by length asc for each color
    Object.keys(map).forEach((k) => {
      map[k] = [...map[k]].sort((a, b) => (a.length ?? 0) - (b.length ?? 0));
    });
    return map;
  }, [variants]);

  const colorKeys = useMemo(() => Object.keys(variantsByColor), [variantsByColor]);

  // Build carousel items: all medias for each color (ordered)
  const carouselItems: CarouselItem[] = useMemo(() => {
    const items: CarouselItem[] = [];

    for (const colorKey of colorKeys) {
      const first = variantsByColor[colorKey]?.[0];

      const medias =
        (first?.medias && first.medias.length > 0)
          ? first.medias
          : first?.image_url
            ? [first.image_url]
            : [];

      for (const url of medias) items.push({ colorKey, imageUrl: url });
    }

    if (items.length === 0) {
      items.push({ colorKey: "default", imageUrl: "/placeholder.svg" });
    }

    return items;
  }, [colorKeys, variantsByColor]);

  // State
  const [quantity, setQuantity] = useState(1);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);

  const [selectedColorKey, setSelectedColorKey] = useState<string | null>(null);
  const [selectedLength, setSelectedLength] = useState<number | null>(null);

  // Init default: first variant -> its color + smallest length for that color
  useEffect(() => {
    if (!variants.length) return;

    const first = variants[0];
    const firstColor = first.color || (colorKeys[0] ?? null);

    if (!selectedColorKey && firstColor) {
      setSelectedColorKey(firstColor);
    }

    if (selectedLength == null && firstColor) {
      const list = variantsByColor[firstColor] || [];
      if (list.length) setSelectedLength(list[0].length);
    }
  }, [variants, colorKeys, variantsByColor, selectedColorKey, selectedLength]);

  // Available lengths for selected color
  const availableLengths = useMemo(() => {
    if (!selectedColorKey) return [];
    return (variantsByColor[selectedColorKey] || []).map((v) => v.length);
  }, [variantsByColor, selectedColorKey]);

  // Current variant = color+length match (else first variant of that color)
  const currentVariant = useMemo(() => {
    if (!variants.length) return null;

    if (!selectedColorKey) return variants[0];

    const list = variantsByColor[selectedColorKey] || [];
    if (!list.length) return variants[0];

    if (selectedLength != null) {
      const exact = list.find((v) => v.length === selectedLength);
      if (exact) return exact;
    }

    return list[0];
  }, [variants, variantsByColor, selectedColorKey, selectedLength]);

  const activePrice = currentVariant?.price ?? product?.price ?? 0;

  // When image changes -> sets color by the image’s colorKey -> sets min length
  const handleSelectImage = (index: number) => {
    setSelectedImageIndex(index);

    const item = carouselItems[index];
    if (!item?.colorKey) return;

    const colorKey = item.colorKey;
    setSelectedColorKey(colorKey);

    const list = variantsByColor[colorKey] || [];
    if (list.length) {
      setSelectedLength(list[0].length);
    }
  };

  const handleSelectColor = (colorKey: string) => {
    setSelectedColorKey(colorKey);

    const list = variantsByColor[colorKey] || [];
    if (list.length) setSelectedLength(list[0].length);

    // Move carousel to first image of that color
    const idx = carouselItems.findIndex((it) => it.colorKey === colorKey);
    if (idx >= 0) setSelectedImageIndex(idx);
  };

  const handleSelectLength = (len: number) => setSelectedLength(len);

  const handleAddToCart = () => {
    if (!product || !currentVariant) return;

    if (currentVariant.stock_count <= 0) {
      alert("Cette variante est en rupture de stock");
      return;
    }

    addToCart(product, currentVariant, quantity);
    setQuantity(1);
  };

  const relatedProducts = useMemo(() => {
    if (!product) return [];
    return products.filter((p) => p.id !== product.id).slice(0, 4);
  }, [products, product]);

  // Loading
  if (productsLoading || variantsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Chargement du produit...</p>
        </div>
      </div>
    );
  }

  // Error / Not found
  if (productsError || variantsError || !product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <AlertCircle className="h-8 w-8 mx-auto text-destructive" />
          <h1 className="font-serif text-2xl font-bold text-foreground">Produit non trouvé</h1>
          <p className="text-muted-foreground">
            {productsError || variantsError || "Ce produit n'existe pas."}
          </p>
          <Link to="/shop">
            <Button className="mt-4">Retour à la boutique</Button>
          </Link>
        </div>
      </div>
    );
  }

  // medias for carousel
  const medias = carouselItems.map((it) => it.imageUrl);

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8">
        <div className="grid lg:grid-cols-2 gap-10">
          {/* Carousel */}
          <MediaCarousel medias={medias} selected={selectedImageIndex} onSelect={handleSelectImage} />

          {/* Details */}
          <div className="space-y-6">
            <div>
              <h1 className="font-serif text-3xl md:text-4xl font-bold text-foreground mb-3">
                {product.name}
              </h1>
              {product.description && (
                <p className="text-muted-foreground leading-relaxed">{product.description}</p>
              )}
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3">
              <span className="font-serif text-3xl font-bold text-foreground">
                {formatPrice(activePrice)}
              </span>
              <span className="text-sm text-muted-foreground">(prix selon longueur)</span>
            </div>

            {/* Stock */}
            <div className="text-sm">
              {currentVariant && currentVariant.stock_count > 0 ? (
                <span className="text-green-600 font-medium">
                  En stock ({currentVariant.stock_count})
                </span>
              ) : (
                <span className="text-red-600 font-medium">Rupture de stock</span>
              )}
            </div>

            {/* Colors & Lengths */}
            {colorKeys.length > 0 && (
              <div className="space-y-2 py-4 border-y border-border">
                {/* Colors */}
                <label className="text-sm font-medium">Couleur</label>
                <div className="flex flex-wrap gap-2">
                  {colorKeys.map((ck) => {
                    const sample = variantsByColor[ck]?.[0];
                    const isSelected = selectedColorKey === ck;

                    return (
                      <button
                        key={ck}
                        type="button"
                        onClick={() => handleSelectColor(ck)}
                        className={cn(
                          "px-4 py-2 rounded-lg border transition-all text-sm font-medium flex items-center gap-2",
                          isSelected
                            ? "border-primary bg-primary/10 text-primary"
                            : "border-border hover:border-primary text-foreground opacity-80"
                        )}
                      >
                        <span
                          className="inline-block w-4 h-4 rounded-full border"
                          style={{ background: sample?.color_hex || "#ddd" }}
                        />
                        {ck}
                      </button>
                    );
                  })}
                </div>

                {/* Lengths */}
                <div className="pt-4 space-y-2">
                  <label className="text-sm font-medium">Longueur (pouces)</label>
                  <div className="flex flex-wrap gap-2">
                    {availableLengths.map((len) => {
                      const isSelected = selectedLength === len;

                      return (
                        <button
                          key={len}
                          type="button"
                          onClick={() => handleSelectLength(len)}
                          className={cn(
                            "px-4 py-2 rounded-lg border transition-all text-sm font-medium",
                            isSelected
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:border-primary text-foreground opacity-80"
                          )}
                        >
                          {len}"
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* Quantity + Add */}
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium">Quantité:</span>
                <div className="flex items-center border border-input rounded-lg">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="p-2 hover:bg-muted transition-colors"
                    disabled={quantity <= 1}
                  >
                    <Minus className="h-4 w-4" />
                  </button>

                  <span className="w-12 text-center font-medium">{quantity}</span>

                  <button
                    type="button"
                    onClick={() => {
                      if (!currentVariant) return;
                      setQuantity((q) => Math.min(currentVariant.stock_count, q + 1));
                    }}
                    className="p-2 hover:bg-muted transition-colors"
                    disabled={!currentVariant || quantity >= currentVariant.stock_count}
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              <Button
                variant="hero"
                size="lg"
                className="w-full"
                onClick={handleAddToCart}
                disabled={!currentVariant || currentVariant.stock_count <= 0}
              >
                <ShoppingBag className="h-5 w-5" />
                Ajouter au panier
              </Button>
            </div>
          </div>
        </div>

        {/* Related */}
        {relatedProducts.length > 0 && (
          <div className="mt-16">
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-foreground mb-8">
              Produits similaires
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
