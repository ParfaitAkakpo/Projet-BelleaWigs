export type ProductCategory =
  | 'natural-wigs'
  | 'synthetic-wigs'
  | 'natural-weaves'
  | 'synthetic-weaves';

/**
 * 🔹 Couleur (table colors)
 */
export interface Color {
  id: string;
  name: string;
  hex_code?: string;
}

/**
 * 🔹 Longueur (table lengths)
 */
export interface Length {
  id: string;
  value: number;
  unit: 'inch' | 'cm';
}

/**
 * 🔹 Variante de produit (table product_variants)
 * 👉 SOURCE DE VÉRITÉ : prix, stock, panier
 */
export interface ProductVariant {
  id: string;

  product_id: string;

  color: Color;
  length: Length;

  price: number;
  price_adjustment?: number;

  stock_count: number;
  sku: string;

  medias?: string[] | null; // images/vidéos liées à la couleur

  is_active: boolean;

  created_at?: string;
  updated_at?: string;
}

/**
 * 🔹 Produit principal
 * 👉 DESCRIPTIF uniquement
 */
export interface Product {
  id: string;

  name: string;
  description: string;

  category: ProductCategory;

  details?: string[] | null;
  extension_type?: string | null;

  featured?: boolean;

  medias?: string[] | null; // image par défaut (fallback)
  image_url?: string; // rétrocompatibilité

  rating?: number;
  review_count?: number;

  is_active?: boolean;
  is_promo?: boolean;

  created_at: string;
  updated_at: string;

  /**
   * 🔹 Champs DÉRIVÉS (frontend only)
   */
  price_min?: number;
  price_max?: number;
  in_stock?: boolean;

  /**
   * 🔹 Relations
   */
  variants?: ProductVariant[];
}
